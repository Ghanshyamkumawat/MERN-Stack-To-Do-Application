import React, { useState, useContext } from 'react';
import TaskContext from '../../context/TaskContext';
import TokenContext from '../../context/TokenContext';
import axios from "../../Axios/axios.js";
import "./createTask.css";

function CreateTask() {
  const { dispatch } = useContext(TaskContext);
  const { userToken } = useContext(TokenContext);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const handleAdd = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!title.trim() || !description.trim()) {
      setError("Please enter title and description");
      return;
    }

    try {
      setLoading(true);
      const res = await axios.post(
        "/task/addTask",
        { title, description },
        { headers: { Authorization: `Bearer ${userToken}` } }
      );
      dispatch({ type: "ADD_TASK", payload: res.data.task });
      setTitle("");
      setDescription("");
      setSuccess("Task added successfully");
    } catch (error) {
      setError(error?.response?.data?.message || "Task could not be added");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="addContainer md:w-1/3 md:mx-auto mx-3 mt-3 flex justify-center">
      <div className='w-11/12'>
        <form onSubmit={handleAdd}>
          <div>
            <label htmlFor="title">Title</label>
            <input
              type="text"
              name="title"
              id="title"
              value={title}
              required
              onChange={(e) => setTitle(e.target.value)}
              className='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5'
            />
          </div>
          <div className='my-3'>
            <label htmlFor="description">Description</label>
            <textarea
              rows={5}
              name="description"
              id="description"
              value={description}
              required
              onChange={(e) => setDescription(e.target.value)}
              style={{ resize: "none" }}
              className='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5'
            />
          </div>
          {error && <p className="text-red-600 text-center mb-2">{error}</p>}
          {success && <p className="text-green-700 text-center mb-2">{success}</p>}
          <div className='flex justify-center'>
            <button type='submit' disabled={loading} className='bg-blue-700 rounded-md text-white px-5 py-1 disabled:bg-blue-400'>
              {loading ? "Adding..." : "Add"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default CreateTask;
