import React, { useContext, useState } from 'react';
import moment from 'moment';
import "./task.css";
import TaskContext from '../../context/TaskContext';
import TokenContext from '../../context/TokenContext';
import axios from '../../Axios/axios.js';
import DeleteIcon from '@mui/icons-material/Delete';

function Task({ task }) {
  const { dispatch } = useContext(TaskContext);
  const { userToken } = useContext(TokenContext);
  const [loading, setLoading] = useState(false);

  const authHeader = { headers: { Authorization: `Bearer ${userToken}` } };

  const handleRemove = async () => {
    if (!task?._id) return;
    try {
      setLoading(true);
      await axios.delete(`/task/removeTask/${task._id}`, authHeader);
      dispatch({ type: "REMOVE_TASK", payload: task._id });
    } catch (error) {
      alert(error?.response?.data?.message || "Task could not be deleted");
    } finally {
      setLoading(false);
    }
  };

  const handleMarkDone = async () => {
    if (!task?._id) return;
    try {
      setLoading(true);
      const res = await axios.patch(
        `/task/updateTask/${task._id}`,
        { completed: !task.completed },
        authHeader
      );
      dispatch({ type: "UPDATE_TASK", payload: res.data.task });
    } catch (error) {
      alert(error?.response?.data?.message || "Task could not be updated");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className='bg-slate-300 py-4 rounded-lg shadow-md flex items-center justify-center gap-2 mb-3'>
      <div className="mark-done">
        <input type="checkbox" className="checkbox" onChange={handleMarkDone} checked={!!task.completed} disabled={loading} />
      </div>
      <div className="task-info text-slate-900 text-sm w-10/12">
        <h4 className="task-title text-lg capitalize">{task.title}</h4>
        <p className="task-description">{task.description}</p>
        <div className='italic opacity-60'>
          <p>{task?.createdAt ? moment(task.createdAt).fromNow() : "just now"}</p>
        </div>
      </div>
      <div className="remove-task text-sm text-white">
        <DeleteIcon
          style={{ fontSize: 30, cursor: loading ? "not-allowed" : "pointer" }}
          onClick={loading ? undefined : handleRemove}
          className="remove-task-btn bg-blue-700 rounded-full border-2 shadow-2xl border-white p-1"
        />
      </div>
    </div>
  );
}

export default Task;
