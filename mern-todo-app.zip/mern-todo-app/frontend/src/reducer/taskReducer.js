function taskReducer(tasks, action) {
  switch (action.type) {
    case "ADD_TASK": {
      return [action.payload, ...tasks];
    }
    case "SET_TASK": {
      return action.payload || [];
    }
    case "REMOVE_TASK": {
      return tasks.filter((task) => task._id !== action.payload);
    }
    case "UPDATE_TASK": {
      return tasks.map((task) => (task._id === action.payload._id ? action.payload : task));
    }
    default: {
      return tasks;
    }
  }
}

export default taskReducer;
