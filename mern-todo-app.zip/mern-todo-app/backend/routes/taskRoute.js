import express from "express";
import { addTask, getTask, updateTask, removeTask } from "../controllers/taskController.js";
import requireAuth from "../middleware/requireAuth.js";

const router = express.Router();

router.post("/addTask", requireAuth, addTask);
router.get("/getTask", requireAuth, getTask);
router.patch("/updateTask/:id", requireAuth, updateTask);
router.delete("/removeTask/:id", requireAuth, removeTask);

export default router;
